// https://docs.metamask.io/guide/ethereum-provider.html#using-the-provider

import React, {useState} from 'react'
import {ethers} from 'ethers'
import SimpleStore_abi from './SimpleStore_abi.json'

const SimpleStorage = () => {

	// deploy simple storage contract and paste deployed contract address here. This value is local ganache chain
	let contractAddress = '0x97D0190aD3A99f04e24cfd54F77B29ac734E249e';

	const [errorMessage, setErrorMessage] = useState(null);
	const [defaultAccount, setDefaultAccount] = useState(null);
	const [connButtonText, setConnButtonText] = useState('Connect Wallet');

	const [currentContractVal, setCurrentContractVal] = useState(null);

	const [provider, setProvider] = useState(null);
	const [signer, setSigner] = useState(null);

	const [contract, setContract] = useState(null);
	const [manufacturer, setmanufacturer] = useState(null);
	const [supplier, setsupplier] = useState(null);
	const [transporter, settransporter] = useState(null);
	const [retailer, setretailer] = useState(null);


	const connectWalletHandler = () => {
		if (window.ethereum && window.ethereum.isMetaMask) {

			window.ethereum.request({ method: 'eth_requestAccounts'})
			.then(result => {
				accountChangedHandler(result[0]);
				setConnButtonText('Wallet Connected');
			})
			.catch(error => {
				setErrorMessage(error.message);
			
			});

		} else {
			console.log('Need to install MetaMask');
			setErrorMessage('Please install MetaMask browser extension to interact');
		}
	}

	// update account, will cause component re-render
	const accountChangedHandler = (newAccount) => {
		setDefaultAccount(newAccount);
		updateEthers();
	}

	const chainChangedHandler = () => {
		// reload the page to avoid any errors with chain change mid use of application
		window.location.reload();
	}


	// listen for account changes
	window.ethereum.on('accountsChanged', accountChangedHandler);

	window.ethereum.on('chainChanged', chainChangedHandler);

	const updateEthers = () => {
		let tempProvider = new ethers.providers.Web3Provider(window.ethereum);
		setProvider(tempProvider);

		let tempSigner = tempProvider.getSigner();
		setSigner(tempSigner);

		let tempContract = new ethers.Contract(contractAddress, SimpleStore_abi, tempSigner);
		setContract(tempContract);	
	}

	// const setManuName = (event) => {
	// 	event.preventDefault();
	// 	console.log('sending ' + event.target.setManu.value + ' to the contract');
	// 	contract.set_Part(event.target.setManu.value);
	// }

    // const setSupplierName = (event) => {
	// 	event.preventDefault();
	// 	console.log('sending ' + event.target.setSupplier.value + ' to the contract');
	// 	contract.set_Tech(event.target.setSupplier.value);
	// }

    // const setTransporter = (event) => 
    // {
	// 	event.preventDefault();
	// 	console.log('sending ' + event.target.setTransporter.value + ' to the contract');
	// 	contract.set_Loc(event.target.setTransporter.value);
	// }

    const setNewContract = (event) =>
    {
		event.preventDefault();
		// console.log('sending: ' + event.target.setManu.value + '' + event.target.setSupplier.value);
        contract.set(event.target.setManu.value , event.target.setSupplier.value , event.target.setTransporter.value , event.target.setRetailer.value)
    }

	const getCurrentVal = async () => {
		let val = await contract.get();
		setmanufacturer(val[0]);
		setsupplier(val[1]);
		settransporter(val[2]);
		setretailer(val[3]);

		setCurrentContractVal(val);
	}
	
	return (
		<div>
		<h4> {"Get/Set Contract interaction"} </h4>
			<button onClick={connectWalletHandler}>{connButtonText}</button>
			<div>
				<h3>Address: {defaultAccount}</h3>
			</div>
			<form onSubmit={setNewContract}>
				<input id="setManu" type="text" placeholder='Enter name of Manufacturer'/>
                <input id="setSupplier" type="text" placeholder='Enter name of Supplier'/>
                <input id="setTransporter" type="text" placeholder='Enter name of Transporter'/>
				<input id="setRetailer" type="text" placeholder='Enter name of Retailer'/>
				<button type={"submit"}> Update Contract </button>
			</form>
			<div>
			<button onClick={getCurrentVal} style={{marginTop: '5em'}}> Get Current Contract Value </button>
			</div>
			<div>Manufacturer: {manufacturer}</div>
			<div>Supplier: {supplier}</div>
			<div>Transporter: {transporter}</div>
			<div>Retailer: {retailer}</div>
			{errorMessage}
		</div>
	);
}

export default SimpleStorage;
